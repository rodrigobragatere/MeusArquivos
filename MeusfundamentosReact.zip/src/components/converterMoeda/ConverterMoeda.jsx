import "./ConverterMoeda.css";
import React, { useState } from "react";
import moedas from "../../data/moedas";

export default (props) => {
    
    let [moeda,setMoeda]=useState(80);
    let [indice,setIndice]=useState(5.2);
    let [setResultado] = useState(0);    

    function quandoMudar(e) {
        setMoeda(e.target.value);        
    }

    function quandoMudar1(e) {
        setIndice(e.target.value);        
    }
    
    function result(setMoeda,setIndice){    
        setResultado = setMoeda/setIndice;        
        return setResultado;            
    }
        
    function getMoedas() {
        return moedas.map((moeda, i) => {
            return (
                <tr key={moeda.id} 
                    className={i % 2 === 0 ? 'Par' : 'Impar'}>                    
                    <td>{moeda.id}</td>
                    <td>{moeda.real}</td>
                    <td>{moeda.moedas}</td>                    
                </tr>
            )
        })
    }

    return (
        <div className="Input">
            <div style={{
                display: 'flex',
                flexDirection: 'column'
            }}>
                
                <div className="TabelaMoeda">
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Real</th>
                        <th>Moedas</th>
                    </tr>
                </thead>
                <tbody>
                    {getMoedas()}
                </tbody>
            </table>
        </div>
                <form>
                    <label>Moeda:<br/>
                     <input type='text'  name="moeda"  value={moeda} onChange={quandoMudar}/>
                    </label><br />
                    <label>Indice:<br/>
                     <input type='text'  name="indice"  value={indice} onChange={quandoMudar1}/>
                    </label><br />
                    <label>Resultado:<br/>
                     <input type='text'  name="resultado"  value={result(moeda,indice).toFixed(2)} />
                    </label><br />
                </form>                
            </div>
        </div>


    );
};