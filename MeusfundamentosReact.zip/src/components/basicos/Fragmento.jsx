import React from "react";

export default function Fragmento(props) {
    return (
        <>
            <h2>Fragmento</h2>
            <p>Cuidado com esse erro!</p>
        </>
    );
}
