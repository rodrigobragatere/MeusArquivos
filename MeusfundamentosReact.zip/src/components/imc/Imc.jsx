import "./Imc.css";
import React, { useState } from "react";
import imcs from "../../data/imcs";

export default (props) => {
    
    let [peso,setPeso]=useState(80);
    let [altura,setAltura]=useState(1.80);
    let [setResultado] = useState(0);

    function quandoMudar(e) {
        setPeso(e.target.value);        
    }

    function quandoMudar1(e) {
        setAltura(e.target.value);
    }

    function result(setPeso, setAltura){    
        setResultado = setPeso/(setAltura*2);        
        return setResultado;            
    }

        
    function getImc() {
        return imcs.map((imc, i) => {
            return (
                <tr key={imc.id} 
                    className={i % 2 === 0 ? 'Par' : 'Impar'}>                    
                    <td>{imc.id}</td>
                    <td>{imc.homen}</td>
                    <td>{imc.mulher}</td>                    
                </tr>
            )
        })
    }

    return (
        <div className="Input">
            <div style={{
                display: 'flex',
                flexDirection: 'column'
            }}>
                
                <div className="TabelaImc">
            <table>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Homem</th>
                        <th>Mulher</th>
                    </tr>
                </thead>
                <tbody>
                    {getImc()}
                </tbody>
            </table>
        </div>
                <form>
                    <label>Peso:<br/>
                     <input type='text'  name="peso"  value={peso} onChange={quandoMudar}/>
                    </label><br />
                    <label>Altura:<br/>
                     <input type='text'  name="altura" value={altura} onChange={quandoMudar1} />
                    </label><br />
                    <label>Resultado:<br/>
                     <input type='text'  name="resultado"  value={result(peso,altura).toFixed(2)} />
                    </label><br />
                </form>                
            </div>
        </div>


    );
};