export default [
    { id: 1, real: "1.00", moedas: "Dolar -5.5" },
    { id: 2, real: "1.00", moedas: "Euro -6.2" },
    { id: 3, real: "1.00", moedas: "Libra- 6.6" },
    { id: 4, real: "1.00", moedas: "Ien - 2" },   
]    