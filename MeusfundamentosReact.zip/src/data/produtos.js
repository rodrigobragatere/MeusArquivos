const produtos = [
    { id: 1, nome: 'Caneta', preco: 2.99 },
    { id: 2, nome: 'Lapis', preco: 1.99 },
    { id: 3, nome: 'iPad', preco: 5899.99 },
    { id: 4, nome: 'Sansung S20 Ultra', preco: 6599.99 },
    { id: 5, nome: 'Notebook', preco: 3409.99 },
    { id: 6, nome: 'Caderno', preco: 19.99 },
    { id: 7, nome: 'Borracha', preco: 4.99 },
    { id: 8, nome: 'Impressora', preco: 889.99 },
    { id: 9, nome: 'Monitor 27', preco: 799.9912334 },
    { id: 10, nome: 'Cadeira', preco: 1239.99 },
]

export default produtos