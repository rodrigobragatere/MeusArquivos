export default [
    { id: 1, homen: "menor 20.7 abaixo do peso", mulher: "menor 19.1 abaixo do peso" },
    { id: 2, homen: "menor 26.4 peso normal", mulher: "menor 25.8 peso normal" },
    { id: 3, homen: "menor 31.1 acima do peso", mulher: "menor 27.3 acima do peso" },
    { id: 4, homen: "maior obesidade morbida", mulher: "maior obesidade morbida" },   
]    