package br.sca.beans;

import br.sca.controller.CtrCadastroUsuario;
import br.sca.model.Usuario;
import br.sca.utils.ExcecaoSCA;
import java.io.Serializable;
import javax.faces.bean.*;

//@ApplicationScoped // para quando mata o servidor
@SessionScoped     // para ate a sessão fechar ou fechar o navegador
//@RequestScoped     // para quando mandar uma requisicao
//@ViewScoped        // para quandro troca de tela
//@CustomScoped      //  configuravel por um comportamento do cliente
//@NoneScoped        // sem escopo ( bin para bin)

@ManagedBean(eager=false)
public class LoginBean implements Serializable{

       private Usuario usuario = new Usuario();

       private boolean usuarioLogado=false;
       
       CtrCadastroUsuario ctrCadastroUsuario = CtrCadastroUsuario.getInstance();
	
	public Usuario getUsuario() {
		return this.usuario;
	}

        public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

       
        public String efetuaLogin(){
            boolean loginValido=false;
            try {
                loginValido = ctrCadastroUsuario.existe(this.usuario);


            } catch (ExcecaoSCA ex) {
                //Logger.getLogger(CursoBean.class.getName()).log(Level.SEVERE, null, ex);
            }

             if (loginValido){
                usuarioLogado = true;
                return "principal?faces-redirect=true";
             }
             else{
                usuarioLogado = false;
               // usuario.setNome("Não existe");
               // usuario = new Usuario();  // limpar o form com os dados
                return "index?faces-redirect=true";
             }
            
	}

        public boolean isUsuarioLogado(){
            return usuarioLogado;
        }

        
	
}
