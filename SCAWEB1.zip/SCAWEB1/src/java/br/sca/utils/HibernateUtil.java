package br.sca.utils;

import java.io.Serializable;

//import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;


public class HibernateUtil {
		
//	    private static Logger logger = Logger.getLogger(HibernateUtil.class);
	    private static SessionFactory factory;
		
	        static{
                    AnnotationConfiguration configuration = new AnnotationConfiguration();
		
                    configuration.configure();
		
                    factory = configuration.buildSessionFactory();
		
		}
		
		public static Session getSession()
		{
//			logger.info("Abrindo nova seção");
			return factory.openSession();
		}
		
		public static void evict(Class classe, Serializable id){
			factory.evict(classe, id);
		}
		
	

}
