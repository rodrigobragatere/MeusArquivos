/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.sca.controller;

import br.sca.utils.*;
import br.sca.dao.*;
import br.sca.model.Curso;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.ObjectNotFoundException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.exception.ConstraintViolationException;

/**
 *
 * @author Usuario
 */
public class CtrCadastroCurso implements Serializable{
    private static CtrCadastroCurso umCtrCadastroCurso;
    CursoDAO cursoDAO;
    Session session = null;
    Transaction transaction = null;
    
    private CtrCadastroCurso(){
           
        
     DAOFactory daoFactory = new DAOFactory();
     cursoDAO = daoFactory.getCursoDAO();
     
    }
    
    public static CtrCadastroCurso getInstance(){
        if (umCtrCadastroCurso == null){
            umCtrCadastroCurso = new CtrCadastroCurso();
        }
        return umCtrCadastroCurso;
    }    
    
    
    public List <Curso> listarTodos(int ordenacao) throws ExcecaoSCA{
        List <Curso>lista = null;
        try {
            session = HibernateUtil.getSession();

            lista = new ArrayList <Curso>();
        
            lista = cursoDAO.pegarTodos(session,ordenacao);
        }
        catch(ExcecaoSCA e)
	{
            throw e;
        }
        catch(RuntimeException e)
	{
            throw new ExcecaoSCA("Erro na listagem dos cursos. Descricao " + e.getMessage());
        }
	finally
	{   session.close();
	}
        
        return lista;
    }
    
    
    private boolean validar(Curso curso) throws ExcecaoSCA {        
                 
                    
            if (curso.getCargaHoraria().intValue() <= 0) {
                throw new ExcecaoSCA("A Carga Horária dave ser maior que 0.") ;
            }            
            if (curso.getDescricao() == null || curso.getDescricao().trim().equals("")) {
                throw new ExcecaoSCA("A descrição do curso é obrigatória.") ;
            }
            if (curso.getNumPeriodos().intValue() <= 0) {
                throw new ExcecaoSCA("O número de períodos deve ser maior que 0.") ;
            }
            
            return true ;
    }

    public void incluir (Curso curso) throws ExcecaoSCA {
        try {
            session = HibernateUtil.getSession();
            if (validar(curso))
              
              transaction = session.beginTransaction();
              cursoDAO.incluir(curso,session);
              transaction.commit();
        }
        
        catch(ExcecaoSCA e)
	{
            throw e;
        }
        catch(RuntimeException e)
	{   if (transaction != null)
            {   try
		{
		   transaction.rollback();
		}
		catch(RuntimeException he)
		{ }
            }
            if (e instanceof ConstraintViolationException){
                throw new ExcecaoSCA("Curso duplicado. Descrição " + ((ConstraintViolationException)e).getSQLException().getNextException().getSQLState());
            }
            else{
                throw new ExcecaoSCA("Erro na inclusão do curso. Descrição " + e.getMessage() + "/" + e.getCause());
            }



        }
        
	finally
	{
            session.close();
	}
        
    }
    
    public void alterar (Curso curso) throws ExcecaoSCA {
        try {
            session = HibernateUtil.getSession();
            if (validar(curso)){
              
              transaction = session.beginTransaction();
              cursoDAO.alterar(curso,session);
              transaction.commit();
            }
        }
        catch(ExcecaoSCA e)
	{
            throw e;
        }
        catch(ObjectNotFoundException e)
	{ if (transaction != null)
	  {   try
	        {
	            transaction.rollback();
		}
		catch(RuntimeException he)
		{
		     	throw new ExcecaoSCA("Erro na alteração do curso. Descricao " + he.getMessage());
		}
	  }
	  throw new ExcecaoSCA("Erro na alteração do curso. Descricao " + "Curso não encontrado.");
	}
	catch(RuntimeException e)
	{   if (transaction != null)
            {   try
		{
		   transaction.rollback();
		}
		catch(RuntimeException he)
		{ }
            }
            throw new ExcecaoSCA("Erro na alteração do curso. Descricao " + e.getMessage());
        }
	finally
	{   
            session.close();
	}
        
    }

        public void excluir (Curso curso) throws ExcecaoSCA {
        try {
            session = HibernateUtil.getSession();
            transaction = session.beginTransaction();
            cursoDAO.excluir(curso,session);
            transaction.commit();
	}
        catch(ExcecaoSCA e)
	{
            throw e;
        }
	catch(ObjectNotFoundException e)
	{ if (transaction != null)
	  {   try
	        {
	            transaction.rollback();
		}
		catch(RuntimeException he)
		{
		     	throw new ExcecaoSCA("Erro na exclusão do curso. Descricao " + he.getMessage());
		}
	  }
	  throw new ExcecaoSCA("Erro na exclusão do curso. Descricao " + "Curso não encontrado.");
	}
	catch(RuntimeException e)
	{   if (transaction != null)
            {   try
		{
		   transaction.rollback();
		}
		catch(RuntimeException he)
		{ }
            }
            if (e instanceof ConstraintViolationException){
                throw new ExcecaoSCA("Curso possuído por alguma disciplina ou aluno. Descrição " + ((ConstraintViolationException)e).getSQLException().getNextException().getSQLState());
            }
            else{
                throw new ExcecaoSCA("Erro na exclusão do curso. Descrição " + e.getMessage() + "/" + e.getCause());
            }
            
        }
	finally
	{   session.close();
	}
        
    }

    public Curso carregar(Curso curso) throws ExcecaoSCA {
        try {
            session = HibernateUtil.getSession();
            curso = cursoDAO.carregar(curso,session);
        }
        catch(ExcecaoSCA e)
	{
            throw e;
        }
	catch(ObjectNotFoundException e)
	{
	  throw new ExcecaoSCA("Erro ao carregar o curso. Descricao " + "Curso não encontrado.");
	}
	catch(RuntimeException e)
	{
           throw new ExcecaoSCA("Erro ao carregar o curso. Descrição " + e.getMessage() + "/" + e.getCause());

        }
        finally
	{   session.close();
	}

        return curso;
    }
    
   

        
        
    }
        
        
    
   