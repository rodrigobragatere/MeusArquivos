/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.sca.report;

import br.sca.controller.CtrCadastroCurso;
import br.sca.utils.ExcecaoSCA;
import br.sca.model.Curso;
import java.util.List;
import net.sf.jasperreports.engine.JRDataSource;

/**
 *
 * @author aluno
 */
public class UsandoCursoDataSource {
    static CtrCadastroCurso ctrCadastroCurso = CtrCadastroCurso.getInstance();
    static List<Curso> cursos;
    
    public static JRDataSource test() throws ExcecaoSCA
    {
        cursos = ctrCadastroCurso.listarTodos(2);
        return new CursoDataSource(cursos);
    }        

}
