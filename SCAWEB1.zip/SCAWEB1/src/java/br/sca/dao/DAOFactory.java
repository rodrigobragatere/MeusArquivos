package br.sca.dao;



public class DAOFactory
{	
	public DAOFactory()
	{
	}

	
	// Aqui entram as implementa��es dos m�todos abstratos 
	// especificados em DAOFactory.
	
        public UsuarioDAO getUsuarioDAO()
	{	return new UsuarioDAO();
	}

        public CursoDAO getCursoDAO()
	{	return new CursoDAO();
	}

        public DisciplinaDAO getDisciplinaDAO()
	{	return new DisciplinaDAO();
	}
	
        public AlunoDAO getAlunoDAO()
	{	return new AlunoDAO();
	}
	
        public ProfessorDAO getProfessorDAO()
	{	return new ProfessorDAO();
	}
        
        public TurmaDAO getTurmaDAO()
	{	return new TurmaDAO();
	}
        
        public AvaliacaoDAO getAvaliacaoDAO()
	{	return new AvaliacaoDAO();
	}
        
}
