/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.sca.controller;

import br.sca.utils.*;
import br.sca.dao.*;
import br.sca.model.Usuario;
import java.io.Serializable;
import org.hibernate.Session;

/**
 *
 * @author Usuario
 */
public class CtrCadastroUsuario implements Serializable{
    private static CtrCadastroUsuario umCtrCadastroUsuario;
    UsuarioDAO usuarioDAO;
    Session session;
    
    private CtrCadastroUsuario(){
           
        
     DAOFactory daoFactory = new DAOFactory();
     usuarioDAO = daoFactory.getUsuarioDAO();
     session = HibernateUtil.getSession();
    }
    
    public static CtrCadastroUsuario getInstance(){
        if (umCtrCadastroUsuario == null){
            umCtrCadastroUsuario = new CtrCadastroUsuario();
        }
        return umCtrCadastroUsuario;
    }    
    

    public boolean existe(Usuario usuario) throws ExcecaoSCA {
        boolean encontrado;
        try {
            encontrado = usuarioDAO.existe(usuario,session);
        } catch (ExcecaoSCA ex)  {
            throw new ExcecaoSCA(ex.getMsg());
        }

        return encontrado;
    }
    
   

        
        
    }
        
        
    
   