/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.sca.dao;


import br.sca.utils.ExcecaoSCA;
import br.sca.model.*;
import java.io.Serializable;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Usuario
 */
public class AlunoDAO implements Serializable{

       
    public List<Aluno> pegarTodos(Session s, int ordenacao) throws ExcecaoSCA {

        Query q;
        String ordem;

        if (ordenacao == 0){
            ordem = "matricula";
        }
        else {
            ordem = "nome";
        }

        try {

           String hql = "from Aluno order by " + ordem;
           q = s.createQuery(hql);
        }
        catch (Exception ex) {
            throw new ExcecaoSCA("Erro ao listar os alunos. Descricao " +
                        ex.getMessage());
        }
        return q.list();
    }
 
    
    public List<Aluno> pegarTodosPorCurso(Curso umCurso,Session s, int ordenacao) throws ExcecaoSCA {
       Query q;

        String ordem;

        if (ordenacao == 0){
            ordem = "matricula";
        }
        else {
            ordem = "nome";
        }

        try {
	String hql = "from Aluno a where a.curso.codigo = :busca order by " + ordem;
	q = s.createQuery(hql);
	q.setParameter("busca",umCurso.getCodigo());

        }
        
        catch (Exception ex) {
            throw new ExcecaoSCA("Erro ao listar os alunos.Descricao " +
                        ex.getMessage());
        }

        return q.list();
    }
    
    
  
    
    
    @SuppressWarnings("empty-statement")
    public void incluir(Aluno aluno, Session s) throws ExcecaoSCA {
        
        try {        
            Transaction t = s.beginTransaction();

	    s.save(aluno);

	    t.commit();
        }
        
        catch (Exception ex) {
            
                throw new ExcecaoSCA("Erro na inclusão do aluno. Descricao " +
                        ex.getMessage());
        }

    }
    
    public void alterar(Aluno aluno, Session s) throws ExcecaoSCA {
        try {
           Transaction t = s.beginTransaction();

	    s.update(aluno);

	    t.commit();

        }
        
        catch (Exception ex) {
                throw new ExcecaoSCA("Erro na alteração do aluno. Descricao " +
                        ex.getMessage());
        }
    }
    
    public void excluir(Aluno aluno, Session s) throws ExcecaoSCA {
        try {
           Transaction t = s.beginTransaction();

           Query q;

           String hql = "from Aluno a where a.matricula = :busca";
	   q = s.createQuery(hql);
	   q.setParameter("busca",aluno.getMatricula());
           aluno = (Aluno) q.list().get(0);

           s.delete(aluno);

	   t.commit();

        }
        
        catch (Exception ex) {
                throw new ExcecaoSCA("Erro na exclusão do aluno. Descricao " +
                        ex.getMessage());
        }
    }

    public Aluno carregar(Aluno umAluno, Session s) throws ExcecaoSCA {

       Query q;

        try {

           String hql = "from Aluno a where a.matricula = :busca";
	   q = s.createQuery(hql);
	   q.setParameter("busca",umAluno.getMatricula());


        }
        
        catch (Exception ex) {
            throw new ExcecaoSCA("Erro ao carregar a aluno. Descricao " +
                        ex.getMessage());
        }
       

       return (Aluno)q.list().get(0);
        
       

    }
    
  
    
}

    

