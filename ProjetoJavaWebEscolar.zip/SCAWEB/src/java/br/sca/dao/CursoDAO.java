/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.sca.dao;

import br.sca.utils.ExcecaoSCA;
import br.sca.model.Curso;
import java.io.Serializable;
import java.util.List;
import org.hibernate.LockMode;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Usuario
 */
public class CursoDAO implements Serializable{

       
    public List<Curso> pegarTodos(Session s, int ordenacao) throws ExcecaoSCA {

 	Query q;
        String ordem;
        if (ordenacao == 0){
            ordem = "codigo";
        }
        else {
           if (ordenacao == 1){
            ordem = "descricao";
           }
           else
           {
            ordem = "cargaHoraria";
           }
        }



        //SQLQuery sqlQuery;
        try {
           /* String sql = "select * from curso";
	    sqlQuery = session.createSQLQuery(sql);
	    sqlQuery.addEntity(Curso.class); */
	    


           String hql = "from Curso order by " + ordem;
           q = s.createQuery(hql);


        } 
        catch(RuntimeException ex)
	{
            throw ex;
        }
        catch(Exception ex)
	{
            throw new ExcecaoSCA("Erro na listagem dos cursos. Descrição " + ex.getMessage());
        }
        //return sqlQuery.list();
        return q.list();
    }
    
    
    public void incluir(Curso curso, Session s) throws ExcecaoSCA {
        try {

	    s.save(curso);
        }
        catch(RuntimeException ex)
	{
            throw ex;
        }
        catch(Exception ex)
	{
            throw new ExcecaoSCA("Erro na inclusão do curso. Descrição " + ex.getMessage() + " " + ex.getLocalizedMessage());
        }
        

    }
    
    public void alterar(Curso curso, Session s) throws ExcecaoSCA {
        try {
           
            Curso c = (Curso) s.load(Curso.class,curso.getCodigo());


            s.lock(c,LockMode.UPGRADE);

	    s.merge(curso);

	    
        }
        catch(RuntimeException ex)
	{
            throw ex;
        }
        catch(Exception ex)
	{
            throw new ExcecaoSCA("Erro na alteração do curso. Descrição " + ex.getMessage());
        }
    }
    
    public void excluir(Curso curso, Session s) throws ExcecaoSCA {
        try {

           Curso c = (Curso) s.load(Curso.class,curso.getCodigo());

           s.delete(c);
        }
        catch(RuntimeException ex)
	{
            throw ex;
        }
        catch (Exception ex) {

            throw new ExcecaoSCA("Erro na exclusão do curso. Descrição " + ex.getMessage() + " " + ex.getLocalizedMessage());

        }
        
        
    }

    public Curso carregar(Curso curso,Session s) throws ExcecaoSCA {
        
       	Query q;

        try {

           String hql = "from Curso c where c.codigo = :busca";
	   q = s.createQuery(hql);
	   q.setParameter("busca",curso.getCodigo());


        }
        catch(RuntimeException ex)
	{
            throw ex;
        }
        catch (Exception ex) {
            throw new ExcecaoSCA("Erro ao carregar 0 curso. Descrição " +
                        ex.getMessage());
        }
        
        return (Curso)q.list().get(0);


    }
    
  
    
}

    

