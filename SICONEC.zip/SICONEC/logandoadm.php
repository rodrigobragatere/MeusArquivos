<?php

 // Parte 1

 $login = $_POST['login'] ;

 $senha = $_POST['senha'] ;


 $query = mysql_query("SELECT * FROM administrador WHERE login='$login' AND senha='$senha'");

 $campo = mysql_fetch_array($query);



 // Parte 2

 if ( mysql_num_rows($query)>0 )
 {
		
	// Redireciona pra HOME

    echo "<script type='text/javascript'>
          document.location.href=\"index.php?pagina=cadastro\"
          </script>
          ";

 }
 else {

	echo '<span style="color:red"><b>Senha ou usu�rio incorreto! tente novamente!</b></span><p>';

 }

?>