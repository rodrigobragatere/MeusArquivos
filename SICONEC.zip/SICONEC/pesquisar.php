<?php

require_once("conexao.php");


 $resultado = mysql_query("SELECT id, nome, sobrenome, email FROM usuarios");

  if (mysql_num_rows($resultado)<=0){
    echo "<b>Nenhum registro encontrado.</b>";
  }
    ?>
	<font color=white  size=6><b>Cadastro de Usuarios</b></font>";
	</br>;
	
	<?php
  while ($arr = mysql_fetch_array($resultado))
  {
    echo '<div class="mensagens2">';
    echo "<b>| Id:</b> " . $arr[0];
    echo "<br />";
    echo "<b>| Nome:</b> " . $arr[1];
    echo "<br />";
    echo "<b>| Sobrenome:</b> " . $arr[2];
    echo "<br />";
    echo "<b>| Email:</b> " . $arr[3];
	echo "<br />";
	echo "<b>--------------------------------------------------------</b> ";  
    echo "<br />";
  }
  echo '<a href="index.php?pagina=home">| VOLTAR </a>';
?>
