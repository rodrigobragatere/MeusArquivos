<?php

  // Parte 1

  $nome      = trim(addslashes($_POST['nome']));
  $sobrenome = trim(addslashes($_POST['sobrenome']));
  $login     = trim(addslashes($_POST['login']));
  $email     = trim(addslashes($_POST['email']));
  $senha     = trim(addslashes($_POST['senha']));
  $confsenha = trim(addslashes($_POST['confsenha']));



  // Parte 2

  if ( (empty($nome)) or (empty($sobrenome)) or (empty($login)) or

  (empty($email)) or (empty($senha)) or (empty($confsenha)) or

  ($senha != $confsenha) ){

      echo '<span style="color:red"><b>Todos campos devem ser preenchidos corretamente.</b><p>';

      echo '<a href="index.php?pagina=cadastro"> Voltar </a>';

      exit;

  }

  $sql = "SELECT id FROM usuarios WHERE email='$email'";

  $query = mysql_query($sql);

  if( mysql_num_rows($query)>0 ){

      echo '<span style="color:red"><b> Usu�rio j� cadastrado no sistema. </b><p>';

      echo '<a href="index.php?pagina=cadastro"> Voltar </a>';

      exit;

  }



  // Parte 4

  $senha = md5($senha);


  $sql = "INSERT INTO usuarios (nome,sobrenome,email,login,senha)
  VALUES ('$nome','$sobrenome','$email','$login','$senha')";

  $query = mysql_query($sql);


  echo '<span style="color:blue"><b>Usu�rio cadastrado.</b></span><p>';


?>