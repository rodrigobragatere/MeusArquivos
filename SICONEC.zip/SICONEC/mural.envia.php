<?php

  require_once ('pagina.segura.php');

  $titulo =  addslashes($_POST["titulo"]);

  $mensagem = strip_tags($_POST["mensagem"]);


  // Parte 1


  if ( (empty($titulo)) || strlen($mensagem)<10 )
  {

    echo '<span style="color:red"><b>Todos campos devem ser preenchidos corretamente.
      Sua mensagem deve conter no m�nimo 10 caracteres.</b><p>';

    echo '<a href="index.php?pagina=mural">Voltar</a>';

    exit;

  }


 // Parte 2

 $id_hash = $_SESSION['id_usuario'];

 $query = mysql_query("SELECT id FROM usuarios WHERE md5(id)='$id_hash'");

 $campo = mysql_fetch_array($query);

 $id_usuario = $campo['id'];

 // Parte 3 

 $sql = "INSERT INTO posts (id_usuario,titulo,texto,data) VALUES ($id_usuario,'$titulo','$mensagem',NOW())";

 $query = mysql_query($sql);


 echo '<span style="color:blue"><b>Mensagem criada com sucesso!</b><p>';

 echo '<a href="index.php?pagina=mensagens"> Ver mensagens </a>';


?>