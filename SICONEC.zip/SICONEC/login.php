<h3><font color=white  size=6> LOGIN USUARIO ADMNISTRADOR</font> </h3>  

<form method="post" action="index.php?pagina=logando">

  <FONT COLOR=WHITE> <p>Usuario:</FONT> <br /> <input type="text" name="login" /></p>

  <FONT COLOR=WHITE> <p>Senha: </FONT> <br /> <input type="password" name="senha" /></p>

   <p><input type="submit" value="Entrar" /></p>

</form>