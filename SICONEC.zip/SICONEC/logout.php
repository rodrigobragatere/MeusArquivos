<?php

  $_SESSION = array();

  echo "<script type='text/javascript'>
        document.location.href=\"index.php?pagina=home\"
        </script>
        ";

?>