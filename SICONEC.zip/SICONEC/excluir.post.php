<?php

  // Parte 1

  session_start();

  require_once("conexao.php");

  require_once("pagina.segura.php");



  // Parte 2

  $id = addslashes($_GET["id"]);

  $id_usuario = $_SESSION['id_usuario'];


  $query = mysql_query("DELETE FROM posts WHERE md5(id)='$id' AND md5(id_usuario)='$id_usuario'");


  echo "<script language='Javascript'>
        alert('Mensagem deletada com sucesso!');
        document.location.href='index.php?pagina=mensagens';
        </script>";

?>