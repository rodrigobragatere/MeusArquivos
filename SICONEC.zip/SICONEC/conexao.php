<?php

$conexao = mysql_connect("localhost","root","")
	or die("N�o foi poss�vel conectar: " . mysql_error());


mysql_select_db("mural")
	or die("Ocorreu um erro: " . mysql_error());

?>


