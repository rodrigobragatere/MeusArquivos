<h3> <font color=white  size=6>Cadastro de usu�rios </font></h3>


<form action="index.php?pagina=cadastrando" method="POST">
    <fieldset>

    <legend>Cadastro de novos usu�rios</legend>

    <FONT COLOR=WHITE> <label for="name">Nome</label></FONT><br />
	<input type="text" name="nome" /><br /><br />

    <FONT COLOR=WHITE><label for="name">Sobrenome</label></FONT><br /> 
	<input type="text" name="sobrenome" /><br /><br />

    <FONT COLOR=WHITE><label for="name">Email</label></FONT><br />
	<input type="text" name="email" /><br /><br />

    <FONT COLOR=WHITE><label for="name">Login</label></FONT><br />
	<input type="text" name="login" /><br /><br />

    <FONT COLOR=WHITE><label for="name">Senha</label></FONT><br />
	<input type="password" name="senha" /><br /><br />

    <FONT COLOR=WHITE><label for="name">Confirma��o de Senha:</label></FONT><br />
	<input type="password" name="confsenha" /><br /><br />

    <input type="submit" value="Cadastrar" /> 
	<input value=Limpar type=reset>

    </fieldset>
</form> 



