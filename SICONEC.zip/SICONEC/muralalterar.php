<h3><font color=white  size=6> Alterar sua mensagem </font></h3>


<form method="post" action="index.php?pagina=mural.atualiza">

<font color=white>Titulo: </font><br /> <input type="text" name="titulo" />
<br /><br />

<font color=white>Mensagem: </font><br /> <textarea name="mensagem" cols="40" rows="8"></textarea>
<br /><br />
<input type="submit" value="Alterar" /> 

</form>