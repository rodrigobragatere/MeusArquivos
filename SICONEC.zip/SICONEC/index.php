<?php

// Parte 1

session_start();

require_once("conexao.php");

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ANSI" />
<link rel="stylesheet" type="text/css" href="style_cinza.css"/>
<title>::Controle de Eventos WEB :: RODRIGO BRAGA</title>
</head>
<body>


<div id="estrutura">


    <div id="esquerda">
        <div class="barra">
            <h1>Menu</h1>
        </div>
        <ul>

            <li><a href="index.php?pagina=home">Home</a></li>

            <?php

            // Parte 2

            if ( !(isset($_SESSION['TreinaMuralLogado'])) ){

            ?>

            <li><a href="index.php?pagina=loginadm">Novo Usuario</a></li>
            <li><a href="index.php?pagina=pesquisar">Pesquisa Usuario</a></li>
			<li><a href="index.php?pagina=login">Login</a></li>

            <?php } ?>


            <li><a href="index.php?pagina=mensagens">Eventos Culturais</a></li>

			<hr> 
				<marquee direction=up scrollamount = "1" <align="center"><center> <font size=4 color=black>
				DESENVOLVIDO POR: <address>Rodrigo Braga - PDS java</address></font><img src="img/JAVA.jpg"> </marquee>	

            <?php

            // Parte 3

            if ( isset($_SESSION['TreinaMuralLogado']) ){

            ?>

            <li><a href="index.php?pagina=mural"><img src='img/inserir.gif'><b> Enviar mensagem</b></a></li>
			 <li><a href="index.php?pagina=muralalterar"><img src='img/alterar.gif'><b>   Alterar mensagem</b></a></li>
            <li><a href="index.php?pagina=logout"><img src='img/sair.gif'><b> Logout</b></a></li>

            <?php } ?>

        </ul>
	<font size=4><center><a href="http://rodrigobragatere.blogspot.com"> <b>blog: Rodrigo Braga</b> </a></center></font>	    
    </div>


    <div id="direita">

        <?php

        // Parte 4          

        $validas = array('home','cadastro','login','logout',
		'cadastrando','logando','mural.envia','mural','mensagens',
		'pesquisar','mural.atualiza','muralalterar','loginadm', 'logandoadm');
        
        if (! empty( $_GET['pagina'] ))
        {

         if ( in_array( $_GET['pagina'] ,$validas) )
            {
                 require_once(  $_GET['pagina']  . ".php");
            }

        }else{

            require_once( "home.php" );

        }
		 
        ?>

    </div>

</div>  
 
</body>
</html>
