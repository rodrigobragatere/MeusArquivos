<html>
<body>
<BR>
<FONT SIZE=6 COLOR=WHITE><b><CENTER>Controle de Eventos</b></CENTER></FONT>
         <hr>
<marquee behavior="alternate" scrollamount = "5" ><a href="http://www.unopar.br"> <img src="img/UNOPAR3.jpg"></a> </marquee>
         <hr> 
<FONT SIZE=6 COLOR=WHITE><b><CENTER>UNOPAR POLO TERESOPOLIS</b></CENTER></FONT>
<?php
echo '<div class="mensagens3">';
$data=date('d/m/Y');
$hora=date('H');
$minutos=date('i');
$segundos=date('s');
if($hora>=12 && $hora<18)
{
echo("Boa Tarde, hoje e $data - $hora:$minutos:$segundos");
}
if($hora>=18 && $hora<24)
{
echo("Boa Noite, hoje e $data - $hora:$minutos:$segundos");
}
if($hora>=24 && $hora<12)
{
echo("Bom Dia, hoje e $data - $hora:$minutos:$segundos");
}
?>
</body>
</html>