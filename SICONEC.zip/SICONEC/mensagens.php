<h3><font color=blue  size=4 Mensagens do Mural </font></h3>


<div class="mensagens">


<?php

    // Parte 1

	$query = mysql_query("SELECT * FROM posts");

    while ($dados = mysql_fetch_array($query))
    {
	echo '<div class="titulo_mural">';

	echo $dados['titulo'];

    // Parte 2

    if( isset($_SESSION['TreinaMuralLogado']) ){

		// Parte 3

  		if ( md5( $dados['id_usuario'] ) == $_SESSION['id_usuario'] ) {

  			$url = "excluir.post.php?id=" . md5( $dados['id'] );
  			echo " - <a href='$url'><img src='img/excluir.gif'>Del</a>";
			
  		}
    }
	
	echo '</div>';

	echo '<div class="mensagem_mural">'. $dados['texto'] .'</div><br />';
    }

?>

</div>
