<?php

if ( !( isset($_SESSION['TreinaMuralLogado']) ) ){

    echo "<script type='text/javascript'>alert('� necess�rio estar logado para acessar esta �rea.');document.location.href=\"index.php?pagina=home\"</script>";

    exit;

}

?>