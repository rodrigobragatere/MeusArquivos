<?php

  require_once ('pagina.segura.php');

  $titulo =  addslashes($_POST["titulo"]);

  $mensagem = strip_tags($_POST["mensagem"]);


  // Parte 1


  if ( (empty($titulo)) || strlen($mensagem)<10 )
  {

    echo '<span style="color:red"><b>Todos campos devem ser preenchidos corretamente.
      Sua mensagem deve conter no minimo 10 caracteres.</b><p>';

    echo '<a href="index.php?pagina=mural">Voltar</a>';

    exit;

  }


 // Parte 2

 $id_hash = $_SESSION['id_usuario'];

 $query = mysql_query("SELECT id FROM usuarios WHERE md5(id)='$id_hash'");

 $campo = mysql_fetch_array($query);

 $id_usuario = $campo['id'];

 // Parte 3 

 $sql = "update posts set id_usuario='$id_usuario',titulo='$titulo',texto='$mensagem',data=NOW() where titulo='$titulo'";
 // $sql =  "UPDATE posts SET  titulo='$titulo',texto=$mensagem', data=NOW() where titulo=$titulo";

 $query = mysql_query($sql);
if($query)
{

echo '<span style="color:blue"><b>Mensagem criada com sucesso!</b><p>';
 echo '<a href="index.php?pagina=mensagens"> Ver mensagens </a>';
}
else
{
echo "ERROR";
}


?>