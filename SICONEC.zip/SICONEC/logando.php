<?php

 // Parte 1

 $login = addslashes( $_POST['login'] );

 $senha = md5( $_POST['senha'] );


 $query = mysql_query("SELECT id FROM usuarios WHERE login='$login' AND senha='$senha'");

 $campo = mysql_fetch_array($query);



 // Parte 2

 if ( mysql_num_rows($query)>0 )
 {

	$_SESSION['TreinaMuralLogado'] = true;

	$_SESSION['id_usuario'] = md5( $campo['id'] );


    // Redireciona pra HOME

    echo "<script type='text/javascript'>
          document.location.href=\"index.php?pagina=home\"
          </script>
          ";

 }
 else {

	echo '<span style="color:red"><b>Senha ou usu�rio incorreto! tente novamente!</b></span><p>';

 }

?>